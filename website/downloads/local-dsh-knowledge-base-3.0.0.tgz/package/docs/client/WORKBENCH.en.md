> Unified project: [main README](../../README.md) · [shared architecture](../../ARCHITECTURE.en.md).

# Installation and use

[中文](WORKBENCH.md) · English

Install into an application directory separate from document libraries. The existing installer requires an empty target. Save work before handling an older installation. Uninstall preserves personal data and settings.

Use the library menu to add a local folder. Removing its registration does not delete source files; the plugin-owned binding is protected. Use the authorization flow for shared libraries instead of copying index databases manually.

Open files in up to four panes and drag tabs to move or merge them. Enable editing before making changes, then save. Ctrl+wheel zooms content; images support drag-to-pan; PDF pages scroll vertically.

Alt+F opens movable global search. Results can be dragged into panes. Explore relationship nodes and previews, organize the inbox and control index inclusion. Model-powered organization requires an online DSH host.

The DSH sidebar offers reconnect, sessions, Agent presets and model/reasoning controls. Enter sends; Shift+Enter inserts a newline. Attach tabs or selected text explicitly. Capabilities depend on the connected host.

Index snapshots are not backups of original files. Confirm backup type and restore target. Preserve originals when editing complex Office documents.


## 当前版本 / Current release

当前本地交付：客户端 2.0.0，配套插件 3.0.0；尚未公开发布。原件分类树读取共享索引；在设置中预览并确认索引迁移。系列成品复用已有目录。

Local client 2.0.0 pairs with plugin 3.0.0; this delivery is not publicly released. The original-file tree uses shared classification. Preview and confirm index migration in Settings. Reuse series folders for deliverables. [Release notes](../releases/client-2.0.0.en.md).
