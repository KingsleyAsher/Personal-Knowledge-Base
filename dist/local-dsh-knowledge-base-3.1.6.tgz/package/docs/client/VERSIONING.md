# 客户端版本与更新 / Client versions and updates

当前版本 / Current versions: client **2.0.0**, plugin **3.0.0**.

[统一版本与自动更新规则 / Authoritative version and update policy](../../VERSIONING.md).

客户端和插件独立版本、标签、清单与摘要。客户端支持检查更新和校验下载，自动覆盖安装与激活尚未接入。Client and plugin retain separate versions, tags, manifests and digests. Client checks and verified downloads are implemented; automatic in-place installation and activation remain unfinished.

[Current release](../releases/client-2.0.3.md).
